<div class="footer">
            
            <div>
                <strong> Food Ordering System 
            </div>
        </div>